Modules
=======

What you can find in this directory:

- **Hardware** - Schematic and PCB files for modules or nodes. The eagle SCH and PCB files need to be downloaded as ZIP in this directory. Otherwise there will be issue when open in Eagle.

- **Libraries** - Libraries use for modules. 
  
- **Examples** - Examples source code to shows how to use the modules/nodes. 



