Yun Shield Hardware Files
=========================

Enables reprogramming of Arduino Leonardo/Uno/Mega with the Dragino Yun Shield.

Put this folder into *sketchbook/hardware/YunShield/*.

For example, if Arduino IDE--> Files --> Preference shows sketchbook location : D:\User\MyDocument\Arduino. Then put the *hardware* folder under D:\User\MyDocument\Arduino.

![install](install.png)
